"""Currency evidence: Excel number formats are read, kept and obeyed.

Fictional data only. A price column formatted in dollars must never reach the
map as pesos, in the preview or in what is stored, and the evidence has to
survive the packed draft that carries a file between requests.
"""

from __future__ import annotations

import io
import unittest

from openpyxl import Workbook

from server import db
from server.asistente.campos import moneda_formato, nombre_moneda
from server.asistente.detectar import interpretar
from server.asistente.perfil import perfilar
from server.asistente.plan import PlanError, construir
from server.asistente.rejilla import Hoja, leer
from tests.test_asistente_api import AsistenteCase

FILAS = [
    ("Terreno", "Precio", "Superficie m2", "Latitud", "Longitud"),
    ("FICTICIO Encino", 1200000, 2400, 19.4326, -99.1332),
    ("FICTICIO Roble", 2500000, 5000, 20.6736, -103.344),
    ("FICTICIO Cedro", 3750000, 7500, 25.6866, -100.3161),
    ("FICTICIO Fresno", 4800000, 9600, 20.5888, -100.3899),
]
PRECIOS = ("B2", "B3", "B4", "B5")


def libro(filas=FILAS, formatos=None, hoja="Terrenos"):
    """A workbook in memory, with a number format on the named cells."""
    wb = Workbook()
    wb.active.title = hoja
    for fila in filas:
        wb.active.append(fila)
    for celda, formato in (formatos or {}).items():
        wb.active[celda].number_format = formato
    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def en_dolares(formato='"USD "#,##0.00'):
    return libro(formatos=dict.fromkeys(PRECIOS, formato))


class Formatos(unittest.TestCase):
    """What a number format does and does not declare."""

    def test_quoted_codes_and_locale_sections_declare_a_currency(self):
        self.assertEqual(moneda_formato('"USD "#,##0.00'), "USD")
        self.assertEqual(moneda_formato('#,##0.00" EUR"'), "EUR")
        self.assertEqual(moneda_formato("[$€-2]#,##0.00"), "EUR")
        self.assertEqual(moneda_formato('[$-409]#,##0.00;[RED]-"USD "#,##0.00'), "USD")

    def test_the_numeric_pattern_itself_declares_nothing(self):
        for formato in ("General", "#,##0.00", "0.00%", "dd/mm/yyyy", "0.00E+00", '0.00" ha"', ""):
            self.assertIsNone(moneda_formato(formato), formato)

    def test_a_bare_peso_sign_is_not_a_foreign_currency(self):
        for formato in ("$#,##0.00", r"\$#,##0", "[$$-409]#,##0.00", '"MXN "#,##0.00', '"$"#,##0'):
            self.assertIsNone(moneda_formato(formato), formato)

    def test_currencies_are_named_for_the_user(self):
        self.assertEqual(nombre_moneda(("USD",)), "dólares")
        self.assertEqual(nombre_moneda(("EUR",)), "EUR")
        self.assertEqual(nombre_moneda(("USD", "EUR")), "USD y EUR")
        self.assertEqual(nombre_moneda(()), "")


class Rejilla(unittest.TestCase):
    """The grid keeps the evidence, and the packed draft carries it along."""

    def test_the_grid_records_which_cells_are_in_a_foreign_currency(self):
        hoja = leer(en_dolares(), "x.xlsx").hojas[0]
        self.assertEqual(hoja.monedas, tuple((f, 1, "USD") for f in (1, 2, 3, 4)))
        self.assertEqual(hoja.monedas_de(1, [1, 2, 3, 4]), ("USD",))
        self.assertEqual(hoja.monedas_de(0, [1, 2, 3, 4]), ())

    def test_only_the_rows_asked_about_count(self):
        hoja = leer(libro(formatos={"B2": '"USD "#,##0.00'}), "x.xlsx").hojas[0]
        self.assertEqual(hoja.monedas_de(1, [1]), ("USD",))
        self.assertEqual(hoja.monedas_de(1, [2, 3, 4]), ())

    def test_an_empty_cell_formatted_in_dollars_is_not_evidence(self):
        filas = [FILAS[0], ("FICTICIO Encino", None, 2400, 19.4326, -99.1332)]
        hoja = leer(libro(filas, {"B2": '"USD "#,##0.00'}), "x.xlsx").hojas[0]
        self.assertEqual(hoja.monedas, ())

    def test_a_column_whose_evidence_was_truncated_carries_it_throughout(self):
        hoja = Hoja(id="sheet:0", nombre="H", filas=(), lineas=(), monedas_truncadas=((1, "USD"),))
        self.assertEqual(hoja.monedas_de(1, []), ("USD",))

    def test_the_packed_draft_keeps_the_currency_of_every_cell(self):
        original = leer(en_dolares(), "x.xlsx")
        vuelta = type(original).desempaquetar(original.empaquetar())
        self.assertEqual(vuelta.hojas[0].monedas, original.hojas[0].monedas)
        self.assertEqual(vuelta, original)

    def test_an_older_draft_without_the_field_still_unpacks(self):
        import base64
        import json
        import zlib
        crudo = {"formato": "csv", "archivo": "x.csv", "sha256": "a", "version": 1,
                 "hojas": [{"id": "csv:,", "nombre": "CSV", "filas": [["Terreno"], ["Norte"]],
                            "lineas": [1, 2], "separador": ",", "formulas_sin_valor": []}]}
        texto = base64.b64encode(zlib.compress(json.dumps(crudo).encode())).decode()
        self.assertEqual(type(leer(b"Terreno\nNorte\n", "x.csv")).desempaquetar(texto).hojas[0].monedas, ())


class Columnas(unittest.TestCase):
    """The profile sees the evidence, whatever wrote it."""

    def perfil(self, contenido):
        rejilla = leer(contenido, "x.xlsx")
        return {c.etiqueta: c for c in perfilar(rejilla.hojas[0], 0)}

    def test_a_dollar_formatted_column_profiles_as_usd(self):
        columna = self.perfil(en_dolares())["Precio"]
        self.assertEqual(columna.monedas, ("USD",))
        self.assertEqual(columna.monedas_formato, ("USD",))
        self.assertEqual(columna.moneda, "USD")

    def test_a_euro_formatted_column_profiles_as_eur(self):
        self.assertEqual(self.perfil(en_dolares("[$€-2]#,##0.00"))["Precio"].monedas, ("EUR",))

    def test_one_foreign_cell_among_pesos_is_enough(self):
        columna = self.perfil(libro(formatos={"B4": '"USD "#,##0.00'}))["Precio"]
        self.assertEqual(columna.monedas, ("USD",))

    def test_a_column_mixing_two_currencies_names_both(self):
        columna = self.perfil(libro(formatos={"B2": '"USD "#,##0.00',
                                              "B4": "[$€-2]#,##0.00"}))["Precio"]
        self.assertEqual(set(columna.monedas), {"USD", "EUR"})

    def test_peso_formats_leave_the_column_in_mxn(self):
        for formato in ("$#,##0.00", '"MXN "#,##0.00', "#,##0.00"):
            self.assertEqual(self.perfil(libro(formatos=dict.fromkeys(PRECIOS, formato)))["Precio"].monedas,
                             (), formato)

    def test_the_text_of_a_column_is_still_read_too(self):
        filas = [FILAS[0], ("FICTICIO Encino", "USD 1,200,000", 2400, 19.4326, -99.1332)]
        self.assertEqual(self.perfil(libro(filas))["Precio"].monedas, ("USD",))


class Importacion(AsistenteCase):
    """Preview and stored records, through the real handlers."""

    def precios_guardados(self):
        with db.session() as conn:
            return [f["asking_price"] for f in conn.execute("SELECT asking_price FROM terreno").fetchall()]

    def test_a_dollar_formatted_price_never_becomes_an_mxn_price(self):
        r = self.analizar("dolares-formato.xlsx", en_dolares())
        self.assertEqual(r["estado"], "vista_previa")
        vista = r["vista_previa"]
        self.assertEqual(vista["conteo"], 4)
        self.assertEqual(vista["con_precio"], 0)
        self.assertTrue(all(f["asking_price"] is None for f in vista["filas"]))
        self.assertEqual(vista["monedas_extranjeras"],
                         [{"columna": "Precio", "letra": "columna B", "monedas": ["USD"], "por_formato": True}])
        self.assertEqual(self.confirmar(r, recordar_formato=False)["base"]["conteo"], 4)
        self.assertEqual(self.precios_guardados(), [None] * 4)

    def test_the_amount_is_kept_as_additional_data_and_explained(self):
        r = self.analizar("dolares-formato.xlsx", en_dolares())
        columna = next(c for c in r["interpretacion"]["columnas"] if c["etiqueta"] == "Precio")
        self.assertEqual((columna["destino"], columna["monedas"]), ("extra", ["USD"]))
        self.assertIn("formato de celda de Excel", columna["motivo"])
        self.assertTrue(any("dólares" in a for a in r["interpretacion"]["avisos"]))
        originales = r["vista_previa"]["filas"][0]["originales"]
        self.assertIn({"columna": "Precio", "valor": "1200000"}, originales)

    def test_pesos_still_import_normally(self):
        for formato in ("$#,##0.00", '"MXN "#,##0.00', "#,##0.00"):
            with self.subTest(formato=formato):
                r = self.analizar("pesos.xlsx", libro(formatos=dict.fromkeys(PRECIOS, formato)))
                self.assertEqual(r["vista_previa"]["con_precio"], 4)
                self.assertEqual(r["vista_previa"]["monedas_extranjeras"], [])
                self.confirmar(r, recordar_formato=False)
                self.assertEqual(self.precios_guardados(), [1200000.0, 2500000.0, 3750000.0, 4800000.0])
                with db.session() as conn:
                    conn.execute("DELETE FROM terreno")
                    conn.execute("DELETE FROM base")

    def test_one_foreign_cell_blocks_the_whole_price_column(self):
        r = self.analizar("mixta.xlsx", libro(formatos={"B4": '"USD "#,##0.00'}))
        self.assertEqual(r["vista_previa"]["con_precio"], 0)
        self.assertEqual(self.precios_guardados(), [])

    def test_a_column_in_two_currencies_names_both(self):
        r = self.analizar("dos.xlsx", libro(formatos={"B2": '"USD "#,##0.00', "B4": "[$€-2]#,##0.00"}))
        monedas = r["vista_previa"]["monedas_extranjeras"][0]["monedas"]
        self.assertEqual(set(monedas), {"USD", "EUR"})
        self.assertEqual(r["vista_previa"]["con_precio"], 0)

    def test_an_explicit_choice_cannot_relabel_a_foreign_column_as_a_price(self):
        r = self.analizar("dolares-formato.xlsx", en_dolares())
        columna = next(c for c in r["interpretacion"]["columnas"] if c["etiqueta"] == "Precio")["id"]
        respuesta = self.preparar(r, correcciones={"columnas": {columna: "asking_price"}})
        self.assertIn("dólares", respuesta["error"])
        self.assertNotIn("vista_previa", respuesta)

    def test_the_evidence_survives_a_later_correction_on_the_draft(self):
        r = self.analizar("dolares-formato.xlsx", en_dolares())
        siguiente = self.preparar(r, correcciones={"decimal": "comma"})
        self.assertEqual(siguiente["vista_previa"]["con_precio"], 0)
        self.assertEqual(siguiente["vista_previa"]["monedas_extranjeras"][0]["monedas"], ["USD"])
        self.confirmar(siguiente, recordar_formato=False)
        self.assertEqual(self.precios_guardados(), [None] * 4)

    def test_a_remembered_format_cannot_bring_a_foreign_column_back_as_a_price(self):
        primero = self.analizar("pesos.xlsx", libro())
        self.confirmar(primero, recordar_formato=True)
        segundo = self.analizar("dolares-formato.xlsx", en_dolares())
        self.assertEqual(segundo["vista_previa"]["con_precio"], 0)

    def test_the_plan_refuses_the_relabelling_even_without_the_service(self):
        from server.asistente.plan import ImportPlan
        rejilla = leer(en_dolares(), "x.xlsx")
        interp = interpretar(rejilla, {})
        columna = next(c for c in interp.columnas if c.etiqueta == "Precio")
        plan = ImportPlan(sha256=rejilla.sha256, hoja_id=interp.hoja.id, encabezado=0, decimal="dot",
                          asignaciones={**interp.asignaciones, columna.id: "asking_price"})
        with self.assertRaises(PlanError) as fallo:
            construir(plan, rejilla)
        self.assertIn("dólares", str(fallo.exception))


if __name__ == "__main__":
    unittest.main()
